/*
Eine Vorlage wird mit class erstellt (nicht zu verwechseln CSS-Klasse)
Beispiel für Person
 */

class Person {
    constructor(firstName, lastName, geschlecht, birthday) {
        this.firstName = firstName;
        this.lastName = lastName;
        this.geschlecht = geschlecht;
        this.birthday = birthday;
    }


    set fullName(fullName) {
        const names = fullName.split(' ');
        this.firstName = names[0];
        this.lastName = names[1];
    }

    get fullName() {
        return `${this.firstName} ${this.lastName}`;
    }

    getFullName(){
        return `Mein Name ist ${this.firstName} ${this.lastName}.`;
    }

    getBio(likes = []) {
        let bio = `Mein Name ist ${this.firstName} ${this.firstName}.`;
        bio = bio + ` Ich bin ${this.geschlecht}`;
        bio += ` und am ${this.birthday} geboren.`;

        if (likes.length > 0) {
            bio += ` In meiner Freizeit tue ich`;
            likes.forEach((like) => {
                bio += ` ${like}`;
            });
        }
        return bio;
    }
}

export default Person;
